# kodi.screensaver.pimon


##Install

Download the latest zip file from: https://github.com/SonRiab/kodi.screensaver.pimon/archive/0.3.3.zip

Use kodi to install this add-on from zip file.
